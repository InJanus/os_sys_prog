This assingment kind of has 2 file options
I first wrote this as a sequential operation (tee_rewrite.c) and then adapted it with a parent, child : consumer, producer model(tee_assignment.c) to satisfy the assingment.
