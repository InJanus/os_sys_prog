gcc -pthread RW_LOCK_TEST-3.c
time ./a.out 1
time ./a.out 5
time ./a.out 10
time ./a.out 20