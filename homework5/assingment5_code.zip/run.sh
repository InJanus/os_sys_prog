python3 generate.py -v 50
gcc -pthread -o threadsort assignment5.c
./threadsort